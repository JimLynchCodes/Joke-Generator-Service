
require("./target/joke-generator/goog/bootstrap/nodejs.js");

// It's not clear why this is necessary
goog.global.CLOSURE_UNCOMPILED_DEFINES = {"cljs.core._STAR_target_STAR_":"nodejs"};

require("./target/joke-generator/joke_generator.js");

goog.require("joke_generator.core");

exports.joke_generator_core_SLASH_echo = joke_generator.core.echo;

